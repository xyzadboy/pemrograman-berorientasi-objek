import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class car here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class car extends Actor
{
    private int speed = 1;
    /**
     * Act - do whatever the car wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
     public void act() {
          moveRandomly();
        }
    
    private void moveRandomly() {
        if(Greenfoot.getRandomNumber(100) < 2) {
            setRotation(Greenfoot.getRandomNumber(360));
        }
        move(speed);
    }
}
    
    
     

